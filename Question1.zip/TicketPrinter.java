public class TicketPrinter
{
public void displayText(String text) 
{
System.out.println("-------------Ticket Printer-------------");
System.out.println(text);
}
}