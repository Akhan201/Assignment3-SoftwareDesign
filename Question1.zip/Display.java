public class Display
{
public void displayText(String text) 
{
System.out.println(".....Display......");
System.out.println(text);
}
}

