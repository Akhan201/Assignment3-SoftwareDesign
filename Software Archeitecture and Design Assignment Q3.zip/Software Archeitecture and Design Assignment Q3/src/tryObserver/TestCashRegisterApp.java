/*package tryObserver;
public class TestCashRegisterApp
{
    public static void main(String[] args)
    {


                Scanner scanner = new Scanner();
                Keyboard keyboard = new Keyboard();

                scanner.scannedUPCCode(1234);
                keyboard.setUPCCode(5678);

                scanner.scannedUPCCode(2222);
                keyboard.setUPCCode(3333);

                scanner.scannedUPCCode(4444);
                keyboard.setUPCCode(5555);

                scanner.scannedUPCCode(6666);
                keyboard.setUPCCode(7777);

                scanner.scannedUPCCode(8888);
                keyboard.setUPCCode(9999);

        }
}*/
