package tryObserver;

abstract class Observer {
    abstract public void onNotify(diss, text);

}
