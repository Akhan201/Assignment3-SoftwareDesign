
public class TicketPrinter implements View
{
    public void displayProduct(Product product)
    {
        System.out.println("-------------Ticket Printer-------------");
        System.out.println(product);
    }


}