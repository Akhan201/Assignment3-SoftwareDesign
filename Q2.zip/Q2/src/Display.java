public class Display implements View
{

    public void displayProduct(Product product)
    {
        System.out.println(".....Display......");


        System.out.println(product);
    }
}
