import java.util.*;

public interface View {
    //the display and ticket printer will inherent from that contains an operator called displayProduct(Product)

    void displayProduct(Product product);
}
