public class CashRegister
{
    public Display display = new Display();
    public TicketPrinter ticketPrinter = new TicketPrinter();
    public Product currentProduct;
    public ProductDB productDB = new ProductDB();
    public int UPCCode;
    public void setCurrentProductUPC(int UPCCode)
    {
        this.UPCCode = UPCCode;
        this.currentProduct = this.getCurrentProductInfo();


        if (this.currentProduct != null)
        {
            this.display.displayProduct(this.currentProduct);
            this.ticketPrinter.displayProduct(this.currentProduct);
        }
    }
    public Product getCurrentProductInfo()
    {
        currentProduct = this.productDB.GetProductInfo(this.UPCCode);
        return currentProduct;
    }
}